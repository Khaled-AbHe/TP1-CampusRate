import { ApiProperty } from '@nestjs/swagger';

/**
 * RFC 7807 — Problem Details for HTTP APIs.
 * Shape returned by ProblemDetailsFilter for every error response,
 * served with Content-Type: application/problem+json.
 */
export class ProblemDetailsDto {
  @ApiProperty({
    description:
      "URI identifiant le type de problème. \"about:blank\" indique que le problème n'a pas de sémantique additionnelle au-delà du code de statut HTTP.",
    example: 'about:blank',
  })
  type!: string;

  @ApiProperty({
    description:
      'Résumé court et lisible du type de problème. Identique pour toutes les occurrences du même type.',
    example: 'Not Found',
  })
  title!: string;

  @ApiProperty({
    description: 'Code de statut HTTP de cette réponse.',
    example: 404,
  })
  status!: number;

  @ApiProperty({
    description:
      'Explication lisible propre à cette occurrence précise du problème.',
    example: "Aucun endroit ne correspond à l'identifiant fourni.",
  })
  detail!: string;

  @ApiProperty({
    description:
      'URI identifiant cette occurrence précise du problème — le chemin de la requête concernée.',
    example: '/api/v1/places/plc_01JABC123',
  })
  instance!: string;
}
