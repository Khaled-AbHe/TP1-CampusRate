import {
  ArgumentsHost,
  Catch,
  ExceptionFilter,
  HttpException,
  HttpStatus,
  Logger,
} from '@nestjs/common';
import { STATUS_CODES } from 'node:http';
import type { Request, Response } from 'express';
import { ProblemDetailsDto } from '../dto/problem-details.dto.js';

/**
 * Catches every exception thrown anywhere in the app and reshapes it into
 * RFC 7807 Problem Details, served as application/problem+json.
 *
 * - HttpException (thrown deliberately, or by the ValidationPipe) keeps its
 *   real status and message.
 * - Anything else is treated as an unexpected technical error: forced to
 *   500, logged server-side with full detail, and never echoed back to the
 *   client (no stack trace, no local path, no raw file content).
 */
@Catch()
export class ProblemDetailsFilter implements ExceptionFilter {
  private readonly logger = new Logger(ProblemDetailsFilter.name);

  catch(exception: unknown, host: ArgumentsHost): void {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();
    const request = ctx.getRequest<Request>();

    const problem =
      exception instanceof HttpException
        ? this.fromHttpException(exception, request)
        : this.fromUnknownException(exception, request);

    response
      .status(problem.status)
      .header('Content-Type', 'application/problem+json')
      .json(problem);
  }

  private fromHttpException(
    exception: HttpException,
    request: Request,
  ): ProblemDetailsDto {
    const status = exception.getStatus();
    const body = exception.getResponse();

    return {
      type: 'about:blank',
      title: STATUS_CODES[status] ?? 'Error',
      status,
      detail:
        typeof body === 'string'
          ? body
          : (this.extractMessage(body) ?? exception.message),
      instance: request.originalUrl ?? request.url,
    };
  }

  private fromUnknownException(
    exception: unknown,
    request: Request,
  ): ProblemDetailsDto {
    // Full detail goes to the server log only — never to the client.
    this.logger.error(
      exception instanceof Error ? exception.stack : exception,
    );

    const status = HttpStatus.INTERNAL_SERVER_ERROR;

    return {
      type: 'about:blank',
      title: STATUS_CODES[status] ?? 'Internal Server Error',
      status,
      detail: 'An unexpected error occurred.',
      instance: request.originalUrl ?? request.url,
    };
  }

  private extractMessage(body: object): string | undefined {
    const message = (body as { message?: string | string[] }).message;
    return Array.isArray(message) ? message.join('; ') : message;
  }
}
